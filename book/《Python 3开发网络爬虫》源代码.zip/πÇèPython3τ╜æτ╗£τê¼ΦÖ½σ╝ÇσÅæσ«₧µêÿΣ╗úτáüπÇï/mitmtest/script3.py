def request(flow):
    url = 'https://httpbin.org/get'
    flow.request.url = url
